<!DOCTYPE html>
<html lang='en' class=''>
<head>
    <!-- Character Set and Responsive Meta Tags -->
    <meta charset='utf-8'/>
    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'/>
    <!-- Site Title -->
    <title>Movies & TVs Shows</title>
    <!-- Bootstrap CSS -->
    <link rel='stylesheet' type='text/css' href='css/bootstrap.css'/>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css'/>
    <!-- Custom Styles -->
    <link rel='stylesheet' type='text/css' href='css/style.css'/>
</head>